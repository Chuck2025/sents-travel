import HttpError from '@wasp/core/HttpError.js'

export const getTours = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };

  return context.entities.Tour.findMany({
    where: {
      userId: context.user.id
    }
  });
}

export const getTour = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };

  const tour = await context.entities.Tour.findUnique({
    where: {
      id: args.tourId,
      userId: context.user.id
    }
  });

  if (!tour) { throw new HttpError(400) }

  return tour;
}