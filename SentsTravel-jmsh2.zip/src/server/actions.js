import HttpError from '@wasp/core/HttpError.js'

export const createTour = async ({ destination, price }, context) => {
  if (!context.user) { throw new HttpError(401) }
  return context.entities.Tour.create({
    data: {
      destination,
      price,
      user: { connect: { id: context.user.id } }
    }
  })
}

export const deleteTour = async ({ tourId }, context) => {
  if (!context.user) { throw new HttpError(401) };

  const tour = await context.entities.Tour.findUnique({
    where: { id: tourId }
  });
  if (tour.userId !== context.user.id) { throw new HttpError(403) };

  return context.entities.Tour.delete({
    where: { id: tourId }
  });
}