import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useQuery } from '@wasp/queries';
import { useAction } from '@wasp/actions';
import getTour from '@wasp/queries/getTour';

export function Tour() {
  const { tourId } = useParams();
  const { data: tour, isLoading, error } = useQuery(getTour, { tourId });
  const updateTourFn = useAction(updateTour);
  const [newTour, setNewTour] = useState({ destination: '', price: 0 });

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  const handleUpdateTour = () => {
    updateTourFn({ id: tourId, ...newTour });
    setNewTour({ destination: '', price: 0 });
  };

  return (
    <div className=''>
      <h2 className='text-2xl font-bold'>Tour Details</h2>
      <div className='my-4'>
        <h3 className='text-lg font-semibold'>Destination: {tour.destination}</h3>
        <p className='text-gray-500'>Price: ${tour.price}</p>
      </div>
      <div className='my-4'>
        <h3 className='text-lg font-semibold'>Edit Tour</h3>
        <div className='flex gap-x-4 py-2'>
          <input
            type='text'
            placeholder='New Destination'
            className='px-1 py-2 border rounded text-lg'
            value={newTour.destination}
            onChange={(e) => setNewTour({ ...newTour, destination: e.target.value })}
          />
          <input
            type='number'
            placeholder='New Price'
            className='px-1 py-2 border rounded text-lg'
            value={newTour.price}
            onChange={(e) => setNewTour({ ...newTour, price: Number(e.target.value) })}
          />
          <button
            onClick={handleUpdateTour}
            className='bg-blue-500 hover:bg-blue-700 px-2 py-2 text-white font-bold rounded'
          >
            Update Tour
          </button>
        </div>
      </div>
      <div className='my-4'>
        <h3 className='text-lg font-semibold'>Back to Dashboard</h3>
        <Link to='/' className='text-blue-500 hover:text-blue-700'>Go to Dashboard</Link>
      </div>
    </div>
  );
}