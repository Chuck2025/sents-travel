import React from 'react';
import { Link } from 'react-router-dom';
import { useQuery } from '@wasp/queries';
import { useAction } from '@wasp/actions';
import getTours from '@wasp/queries/getTours';
import deleteTour from '@wasp/actions/deleteTour';

export function Dashboard() {
  const { data: tours, isLoading, error } = useQuery(getTours);
  const deleteTourFn = useAction(deleteTour);

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  return (
    <div className='p-4'>
      {tours.map((tour) => (
        <div
          key={tour.id}
          className='flex items-center justify-between bg-gray-100 p-4 mb-4 rounded-lg'
        >
          <div>{tour.destination}</div>
          <div>{tour.price}</div>
          <div>
            <button
              onClick={() => deleteTourFn({ tourId: tour.id })}
              className='bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded'
            >
              Delete
            </button>
          </div>
        </div>
      ))}
      <Link to='/create-tour' className='bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded'>Create Tour</Link>
    </div>
  );
}